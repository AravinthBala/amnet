# CodeIgniter-Crud-with-AJAX
CodeIgniter CRUD Application using AJAX and DataTables


In this Code Sample I’m using several framework and library:

PHP+ MySQL or you may use XAMPP
Codeigniter 3.0
jQuery 2.1.4 
Twitter Bootstrap 3.3.5
DataTables 1.10.7

Steps:
1-Download the Zip file.
2-Unzip it and place it on your xamp pr wamp.
3-Create Database "ajax_ci_crud" in your PhpMyAdmin.
4-Import the sql file into the Database you can find in the  zip file you download from here.
5-Run your app and enjoy.
